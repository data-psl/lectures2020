---- Exploring the mobility dataset

-- 2.
\d mobility

-- 3.
SELECT COUNT(*) FROM mobility;

-- 4.
SELECT * FROM mobility LIMIT 10;

-- 5.
SELECT DISTINCT sub_region_1, sub_region_2
FROM mobility
WHERE country_region = 'France'
ORDER BY sub_region_1;
-- Entries corresponding to the whole of France have empty sub_region_1
-- and sub_region_2

-- 6.
SELECT MIN(date), MAX(date) FROM mobility;

-- 7.
SELECT COUNT(DISTINCT country_region_code) FROM mobility;

-- 8.
SELECT country_region_code, AVG(transit)
FROM mobility
WHERE sub_region_1='' AND sub_region_2='' AND metro_area=''
GROUP BY country_region_code HAVING AVG(transit)>0;

-- 9.
SELECT date, workplaces AS workplaces, transit AS transit
FROM mobility
WHERE country_region_code ='FR' AND sub_region_1='Île-de-France' AND sub_region_2=''
ORDER BY date DESC;

---- Importing the ISO 3166-1 dataset

-- 2.
CREATE TABLE iso_3166_1(
  name TEXT NOT NULL UNIQUE,
  alpha2 CHAR(2) NOT NULL PRIMARY KEY,
  alpha3 CHAR(3) NOT NULL UNIQUE,
  country_code CHAR(3) NOT NULL UNIQUE,
  iso_3166_2 CHAR(13) NOT NULL UNIQUE,
  region TEXT,
  sub_region TEXT,
  intermediate_region TEXT,
  region_code CHAR(3),
  sub_region_code CHAR(3),
  intermediate_region_code CHAR(3)
);

-- 3.
\copy iso_3166_1 FROM 'all.csv' WITH (FORMAT csv, DELIMITER ',', QUOTE '"', HEADER);

-- Some optional cleanup to transform empty strings into NULLs
UPDATE iso_3166_1 SET region = NULL WHERE region = '';
UPDATE iso_3166_1 SET sub_region = NULL WHERE sub_region = '';
UPDATE iso_3166_1 SET intermediate_region = NULL WHERE intermediate_region = '';
UPDATE iso_3166_1 SET region_code = NULL WHERE region_code = '';
UPDATE iso_3166_1 SET sub_region_code = NULL WHERE sub_region_code = '';

-- 4.
SELECT name, AVG(workplaces)
FROM mobility JOIN iso_3166_1 ON country_region_code=alpha2
WHERE sub_region_1='' AND sub_region_2='' AND region='Europe'
GROUP BY name ORDER BY AVG(workplaces);

-- 5.
SELECT name, AVG(workplaces)
FROM mobility JOIN iso_3166_1 ON country_region_code=alpha2
WHERE sub_region_1='' AND sub_region_2='' AND region='Europe' AND DATE >= '2020-08-15'
GROUP BY name ORDER BY AVG(workplaces);

---- Importing the stringency dataset

-- 2.
CREATE TABLE stringency(
  entity TEXT NOT NULL,
  code VARCHAR(8) NOT NULL,
  date DATE NOT NULL,
  stringency FLOAT NOT NULL,
  PRIMARY KEY(code, date),
  UNIQUE(entity, date),
  CHECK(stringency>=0 AND stringency<=100)
);
\copy stringency FROM 'covid-stringency-index.csv' WITH (FORMAT csv, DELIMITER ',', QUOTE '"', HEADER);

-- 3.
SELECT name, AVG(stringency) AS stringency FROM iso_3166_1 JOIN stringency on alpha3=code GROUP BY name ORDER BY AVG(stringency) DESC;

-- 4.
SELECT name, AVG(stringency) AS stringency FROM iso_3166_1 JOIN stringency on alpha3=code WHERE date>='2020-08-15' GROUP BY name ORDER BY AVG(stringency) DESC;

-- 5.
SELECT sub_region, AVG(stringency) AS stringency, AVG(workplaces) AS workplaces FROM mobility JOIN iso_3166_1 ON country_region_code=alpha2 JOIN stringency on alpha3=code WHERE sub_region_1='' AND sub_region_2='' GROUP BY sub_region ORDER BY AVG(workplaces);
