#!/usr/bin/env python3

import psycopg2
import scipy.stats

conn = psycopg2.connect("dbname='psl' user='pslXXX' host='senellart.com' password='XXX'")

cur_regions = conn.cursor()
cur_regions.execute("""SELECT DISTINCT region FROM iso_3166_1""")

for r in cur_regions.fetchall():
    print("Region: %s"%r)
        
    cur = conn.cursor()
    cur.execute("""SELECT name, AVG(stringency) AS stringency,
            AVG(workplaces) AS workplaces FROM mobility JOIN iso_3166_1 ON
            country_region_code=alpha2 JOIN stringency on alpha3=code WHERE
            sub_region_1='' AND sub_region_2='' AND region=%s GROUP BY
            name""",(r[0],))
    rows =cur.fetchall()

    print("%d countries"%(len(rows)))

    if(len(rows)<5):
        print("Not enough data")
        continue

    a=[]
    b=[]

    for r in rows:
        a.append(float(r[1]))
        b.append(float(r[2]))

    print(scipy.stats.spearmanr(a,b))
